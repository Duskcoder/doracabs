function color(){
    let oneway=document.getElementById('oneway');
    oneway.style.backgroundColor = "black";
    oneway.style.color="#FFBF00";
    let round=document.getElementById('round');
    round.style.backgroundColor="#FFBF00";
    round.style.color="black";   
}
function color1(){
    let oneway=document.getElementById('oneway');
    oneway.style.backgroundColor = "#FFBF00";
    oneway.style.color="black";
    let round=document.getElementById('round');
    round.style.backgroundColor="black";
    round.style.color="#FFBF00";   
}
