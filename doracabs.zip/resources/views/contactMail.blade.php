<h2>Hey !</h2> <br><br>

You received an email from : {{ $name }} <br><br>

User details: <br><br>

Name:  {{ $name }}<br>
Phone:  {{ $mobile_number }}<br>
Email:  {{ $email }}<br>
Message:  {{ $messages }}<br><br>

Thanks