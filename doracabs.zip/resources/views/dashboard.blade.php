@extends('layouts.app')
@section('content')
<div class="page-content">
                <div class="container-fluid">
                    <!-- Page-Title -->
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title-box">
                                <div class="row">
                                </div><!--end row-->
                            </div><!--end page-title-box-->
                        </div><!--end col-->
                    </div><!--end row-->
                    <!-- end page title end breadcrumb -->
                    <p style="width: 100%;"><h1 style="text-align: center;">Welcome to DoraCabs</h1></p>


                </div><!-- container -->
            </div>
@endsection
